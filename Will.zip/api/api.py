pessoa = {
    "nome" : "Oberdan",
    "idade": 44,
    "filhos": [
        {
            "nome": "William"
        },
        {
            "nome": "Melissa"
        }
    ]
}

print(pessoa['nome'])
for filho in pessoa["filhos"]:
    print(filho['nome'])