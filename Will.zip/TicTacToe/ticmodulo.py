import numpy as np
import re

#printa o tabuleiro

def printgame():
    matriz = np.full((4, 4), ' ')
    matriz[:, 0] = ['', '1', '2', '3']
    matriz[0, :] = ['*', '1', '2', '3']
    print('\n', matriz, '\n')
    return matriz

#faz a escolha

def pchoice(user): 
    if user == 'p1':
        letter = 'X'
    elif user == 'p2':
        letter = 'O'
    userChoice = input("sua vez, onde vai colocar o {}? (digie as coordenadas separadas por espaço, com o Y primeiro e depois o X)\n".format(letter))
    userChoice = userChoice.split(' ')
    return userChoice

#faz a reacção do tabuleiro

def greact(user, x, y, matriz):
    if user == 'p1':
        matriz[:, 0] = ['', '1', '2', '3']
        matriz[0, :] = ['*', '1', '2', '3']
        matriz[x, y] = 'X'
        return matriz
    else:
        matriz[:, 0] = ['', '1', '2', '3']
        matriz[0, :] = ['*', '1', '2', '3']
        matriz[x, y] = 'O'
        return matriz

#testa a validade dos valores inseridos no tm.pchoice

def test(item, matriz):
    return len(item) == 2 and str.isnumeric(item[0]) and str.isnumeric(item[1]) and matriz[int(item[0]), int(item[1])] == ' '



def testwinner(matriz):
    reGex = '(?P<diagonal>X\s{3}X\s{2}X)|(?P<horizontal>X{3})|(?P<vertical>X\s{2}X\s{2}X)'
    matriz = int(matriz)
