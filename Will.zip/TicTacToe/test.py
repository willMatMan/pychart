import numpy as np
import re
matriz = np.full((4, 4), ' ')
matriz[:, 0] = ['', '1', '2', '3']
matriz[0, :] = ['*', '1', '2', '3']

def testwinner(matriz):
    regex = '(?P<diagonal>X\s{3}X\s{2}X)|(?P<horizontal>X{3})|(?P<vertical>X\s{2}X\s{2}X)/gm'
    matriz_substituicao1 = np.full((4, 4), ' ')
    matrizfinal1 = np.where(matriz == matriz_substituicao1, 'E', matriz)
    matrizfinal1 = matrizfinal1.flatten()
    matrizfinal1 = ' '.join(matrizfinal1)
    result = re.match(regex, matrizfinal1)
    diagonal = result.group('diagonal')
    horizontal = result.group('horizontal')
    vertical = result.group('vertical')
    



print()
# # cria uma matriz 3x3 preenchida com o valor 2
# matriz = np.full((3, 3), 2)

# # cria uma matriz com os valores que deseja substituir
# substituir_valor = np.full((3, 3), 3)

# # substitui todos os valores iguais a 3 por 4
# matriz = np.where(matriz == substituir_valor, 4, matriz)

# print(matriz)


# matriz = np.full((3, 3), 'a')
# matriz = matriz.flatten()
# matriz = ''.join(matriz)






