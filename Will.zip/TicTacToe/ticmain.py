import ticmodulo as tm
import numpy as np

#declarando variaveis

p1c = 'none'
p2c = 'none'
matriz = np.full((4, 4), ' ')
turn = ['p1', 'p2']
test = 'error'


#mostrando o tabuleiro

tm.printgame()



while True:
    for x in turn:
        test = 'error'
        while True:
            pc = tm.pchoice(x)
            success = tm.test(pc, matriz)

            if success:
                if x == 'p1':
                    p1c = pc 
                    matriz = tm.greact('p1', int(p1c[0]), int(p1c[1]), matriz)
                else:
                    p2c = pc
                    matriz = tm.greact('p2', int(p2c[0]), int(p2c[1]), matriz)
                print(matriz)
                break
            else:
                print('error')












































            # if x == 'p1':
            #     p1c = tm.pchoice(x)
            #     success = tm.test(p1c)
            # else:
            #     p2c = tm.pchoice(x)
            #     success = tm.test(p2c)
                
            # if test != 'error':

        


    # #laço 1
# while gamestat == "active":






# #verifica o turno
#     if turn == 'p1':
        
#         while True:
#             #faz escolha
#             p1c = tm.pchoice('p1')
#             #testa se o valor inserido é valido
            


#             if matriz[int(p1c[0]), int(p1c[1])] == ' ':
#                 matriz[int(p1c[0]), int(p1c[1])] = 'X'
#                 #matriz = tm.greact('p1', int(p1c[0]), int(p1c[1]), matriz) 
#                 turn = 'p2'
#                 break
#             elif (matriz[int(p1c[0]), int(p1c[1])] == 'X') or (matriz[int(p1c[0]), int(p1c[1])] == 'O'):
#                 print('erro, esse local já está ocupado')
#         print(matriz)
#     else:
#         while True:
#             p2c = tm.pchoice('p2')

#             try:
#                 for x in p2c: x = int(x)
#             except:
#                 print('valor invalido')
#                 break

#             if matriz[int(p2c[0]), int(p2c[1])] == ' ':
#                 matriz[int(p2c[0]), int(p2c[1])] = 'O'
#                 #matriz = tm.greact('p2', int(p2c[0]), int(p2c[1]), matriz)
#                 turn = 'p1'
#                 break
#             elif (matriz[int(p2c[0]), int(p2c[1])] == 'X') or (matriz[int(p2c[0]), int(p2c[1])] == 'O'):
#                 print('erro, esse local já está ocupado')
#         print(matriz)