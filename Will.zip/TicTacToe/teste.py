import ticmodulo as tm
import numpy as np

def getUserChoice(user):
    while True:
        userChoice = input("sua vez, onde vai colocar o {}? (digie as coordenadas separadas por espaço, com o Y primeiro e depois o X)\n".format(user))
        userChoice = userChoice.split(' ')
        error = False

        for coord in userChoice:
            if (not str.isnumeric(coord)) or int(coord) < 1 or int(coord) > 3:
                print('Entrada no formato inválido\n')
                error = True
                break
        
        if error: continue
        
        return userChoice
    

gameActive = True
matriz = np.full((4, 4), ' ')

#define jogador x
users = ['X', 'O']
currentUser = users[0]

while gameActive:
    print(matriz, '\n')

    #obtem escolha do x
    userChoice = getUserChoice(currentUser)

    #verifica se a posição está vazia
    if matriz[int(userChoice[0]), int(userChoice[1])] != ' ':
        print('Essa posição já está ocupada')
        continue

    #ocupa a posição escolhida
    matriz[int(userChoice[0]), int(userChoice[1])] = currentUser
    
    #verifica se ganhou

    #troca jogador
    if users.index(currentUser) == 0:
        currentUser = users[1]
    else:
        currentUser = users[0]



print('fim do jogo')


