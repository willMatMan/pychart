import re
import math

equacao = input('digite uma equação de segundo grau:\n')
equacao = equacao.replace(' ', '')

pattern = '^(?P<a>[\-+]?[0-9]*)x\^2(?P<b>[\-+][0-9]?]*)x?(?P<c>[\-+][0-9]*)=0'
result = re.match(pattern, equacao)


a = int(result.group('a'))
b = int(result.group('b'))
c = int(result.group('c'))

delta = b**2 - 4*a*c
x1 = (-b + math.sqrt(delta)) / (2*a)
x2 = (-b - math.sqrt(delta)) / (2*a)

print('a solução da equação 1x^2 + 4x -2 = 0 é:\n s = {}; {}'.format(x1, x2))

